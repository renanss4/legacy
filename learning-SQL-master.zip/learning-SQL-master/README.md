# learning-SQL
Estudo em SQL

"""
DocString
E escrever o que eu
quiser


asdfasdfd
"""

''' Usar para escrever suas notas '''

# Permite escrever um comentário
print(123)  # Na frente
# Abaixo
print(456)

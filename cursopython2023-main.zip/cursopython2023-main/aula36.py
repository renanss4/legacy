"""
Operadores de atribuição
= += -= *= /= //= **= %=
"""
contador = 10

###

contador /= 5
print(contador)

# import uma_linha
# import varias_linhas
# import documentando_funcoes
import documentando_class

# print(dir(uma_linha))
# print(uma_linha.__doc__)
# print(uma_linha.__file__)
# print(uma_linha.__name__)
help(documentando_class)

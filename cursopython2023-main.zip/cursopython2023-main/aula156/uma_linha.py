"""O que seu módulo faz"""

variavel = 'valor'


def funcao():
    return 1

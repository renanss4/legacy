variavel_modulo = 'Luiz'


def soma(x, y):
    return x + y

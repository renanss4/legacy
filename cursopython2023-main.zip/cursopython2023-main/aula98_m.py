print(123)

variavel = 'Luiz 1'

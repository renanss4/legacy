# Jupyter Notebook - Instalação e teste

# Essa linha cria uma variável a
a = 2

# Essa linha tem o valor da variável `a` em dobro
b = a * 2  # 4

# Essa linha mostra o valor de `a` + `b`
print(a + b)  # 6

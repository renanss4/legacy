# __all__ = [
#     'variavel',
#     'soma_do_modulo',
#     'nova_variavel',
# ]
# from aula99_package.modulo_b import fala_oi

variavel = 'Alguma coisa'


def soma_do_modulo(x, y):
    return x + y


nova_variavel = 'OK'
# fala_oi()

def falar_oi():
    print('oi')

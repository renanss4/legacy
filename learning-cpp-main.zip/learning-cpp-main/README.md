# learning-cpp
Learning c++ to create games and AI projects in the future

I will use VSCode as my IDE. In the future, I will organize this repository better

At first I will be following the playlist below:

- https://youtube.com/playlist?list=PLzMcBGfZo4-lmGC8VW0iu6qfMHjy7gLQ3&si=Gwmo6K1p6ZU5Bcf0

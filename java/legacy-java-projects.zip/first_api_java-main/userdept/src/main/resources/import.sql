INSERT INTO tb_department(name) VALUES ('Gestão');
INSERT INTO tb_department(name) VALUES ('Informática');

INSERT INTO tb_user(name, email, department_id) VALUES ('Maria', 'maria@gmail.com', 1);
INSERT INTO tb_user(name, email, department_id) VALUES ('Bob', 'bob@gmail.com', 1);
INSERT INTO tb_user(name, email, department_id) VALUES ('Alex', 'alex@gmail.com', 2);
INSERT INTO tb_user(name, email, department_id) VALUES ('Ana', 'ana@gmail.com', 2);


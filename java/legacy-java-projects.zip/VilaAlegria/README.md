# VilaAlegria

Exercício para testar lógica e aprendizado da linguagem de tecnologia Java

O objetivo deste projeto é utilizar toda lógica com o conceito de POO e também,

É utilizado Spring Boot no server-side e React no client-side, o Banco de escolhido foi o MySQL.

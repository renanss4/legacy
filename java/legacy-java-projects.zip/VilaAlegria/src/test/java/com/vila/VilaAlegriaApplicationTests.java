package com.vila;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VilaAlegriaApplicationTests {

	@Test
	void contextLoads() {
	}

}

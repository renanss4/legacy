package com.union.controller;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

@WebMvcTest
public class CoordenadorControllerTest {
	
}

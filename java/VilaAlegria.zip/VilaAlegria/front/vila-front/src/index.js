import React from 'react';
import ReactDOM from 'react-dom';
import Morador from './components/Morador';

ReactDOM.render(
  <div>
    <Morador />
  </div>,
  document.getElementById('root')
);


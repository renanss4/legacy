# SA-iWork
1ª SA (projeto de conclusão de fase) do curso técnico em desenvolvimento de sistemas. Aprendi a fazer um sistema completo salvando os dados no LocalStorage, fazendo a verificação de senha e usuário, desenvolvi uma boa lógica, mais criatividade e mais facilidade em aprender novas tecnologias. Sigo aprendendo cada vez mais.

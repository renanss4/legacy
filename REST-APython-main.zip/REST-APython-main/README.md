# REST-APython
Objective of creating the first CRUD with Python, I will use Flask. I will also try to use swagger and some database
